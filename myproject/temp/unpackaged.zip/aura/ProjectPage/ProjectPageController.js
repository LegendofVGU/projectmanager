({
	doInit: function(component,event, helper) {
		helper.getData(component,event,helper);
	},
})